package exam;

import java.util.Scanner;

public class Exam_02 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.print("임의의 정수를 입력하세요. : ");
		int num = sc.nextInt();
		
		int num2 = num * num;
		int num3 = num2 * num;
		
		System.out.println();
		System.out.println("입력받은 정수 ==> " + num);
		System.out.println(num + "의 제곱근 ==> " + num2);
		System.out.println(num + "의 세제곱근 ==> " + num3);
		
		sc.close();
	}
}